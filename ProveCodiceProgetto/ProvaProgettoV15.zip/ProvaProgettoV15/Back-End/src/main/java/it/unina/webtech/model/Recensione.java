package it.unina.webtech.model;

public class Recensione {
    private String commento;

    private int valutazione;

    private Cliente clienteProprietario;

    private Agente agenteRecensito;
}
