package it.unina.webtech.model;

import java.util.ArrayList;

public class Immobile {
    private String descrizioneImmobile;

    private int longitudine;

    private int latitudine;

    private int foto;

    private int dimensione;

    private String via;

    private String comune;

    private String numeroCivico;

    private int NumeroStanze;

    private int piano;

    private String classeEnergetica;

    private ArrayList<Visita> visiteImmobile;

    private Agente agenteProprietario;


}
