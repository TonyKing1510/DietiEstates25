package com.example.prova2.utility;

import com.example.prova2.model.Admin;

public class URLCfFactory {
    private String baseUrl = "http://localhost:9094/not?cf=";

    public String getBaseUrl() {
        return baseUrl;
    }
}
