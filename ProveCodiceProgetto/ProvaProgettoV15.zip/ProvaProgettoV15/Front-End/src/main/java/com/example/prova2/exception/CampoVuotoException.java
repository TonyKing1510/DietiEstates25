package com.example.prova2.exception;

public class CampoVuotoException extends Throwable {
    public CampoVuotoException() {}
}
