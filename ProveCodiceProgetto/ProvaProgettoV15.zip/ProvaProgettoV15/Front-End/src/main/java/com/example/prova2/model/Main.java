package com.example.prova2.model;

public class Main {
    public static void main(String[] args) {

    }
}