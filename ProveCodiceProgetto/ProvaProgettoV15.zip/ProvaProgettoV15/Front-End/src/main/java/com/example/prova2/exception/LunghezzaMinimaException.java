package com.example.prova2.exception;

public class LunghezzaMinimaException extends RuntimeException {
    public LunghezzaMinimaException(String message) {
        super(message);
    }
}
