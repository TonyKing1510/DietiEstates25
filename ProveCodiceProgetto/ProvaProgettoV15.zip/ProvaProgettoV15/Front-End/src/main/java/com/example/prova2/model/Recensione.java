package com.example.prova2.model;

public class Recensione {
    private String commento;

    private int valutazione;

    private Cliente clienteProprietario;

    private Agente agenteRecensito;
}
