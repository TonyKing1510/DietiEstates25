package com.example.prova2.exception;

public class LunghezzaMassimaException extends RuntimeException {
    public LunghezzaMassimaException(String message) {
        super(message);
    }
}
