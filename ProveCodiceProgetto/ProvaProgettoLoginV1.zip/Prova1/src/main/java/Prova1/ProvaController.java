package Prova1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;

import javax.swing.text.html.ImageView;
import java.util.Objects;

public class ProvaController {
    @FXML
    private Label welcomeText;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label emailErrorLabel;

    @FXML
    private Label passwordErrorLabel;

    @FXML
    private Button signInButton;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private void handleSignIn(ActionEvent actionEvent) {
        // Reset messaggi di errore
        emailErrorLabel.setVisible(false);
        passwordErrorLabel.setVisible(false);

        // Flag di validazione
        boolean valid = true;

        // Verifica se l'email è vuota
        if (emailField.getText().trim().isEmpty()) {
            emailErrorLabel.setVisible(true);
            valid = false;
        }

        // Verifica se la password è vuota
        if (passwordField.getText().trim().isEmpty()) {
            passwordErrorLabel.setVisible(true);
            valid = false;
        }

        // Se i campi sono completi, procedi con l'autenticazione
        if (valid) {
            System.out.println("Login successful!");
            // Aggiungi qui il codice per l'autenticazione
        }
    }
    }