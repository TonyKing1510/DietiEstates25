module com.example.prova1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens Prova1 to javafx.fxml;
    exports Prova1;
}